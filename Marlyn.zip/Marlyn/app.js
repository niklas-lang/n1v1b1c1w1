 var express = require("express"),
	app = express(),
	methodOverride = require("method-override"),
	bodyParser = require("body-parser"),
    multer  = require('multer'),
	mongoose = require("mongoose")
	, util     = require('util')
    , path     = require('path');

var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, __dirname + '/uploads')      //you tell where to upload the files,
  },
  filename: function (req, file, cb) {
    cb(null, file.fieldname + '-' + Date.now() + '.png')
  }
})


var upload = multer({storage: storage,
    onFileUploadStart: function (file) {
      console.log(file.originalname + ' is starting ...')
    },
});


mongoose.set('useUnifiedTopology', true);
mongoose.connect("mongodb://localhost:27017/blog_app", {useNewUrlParser : true });
app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static("public"));
app.set("view engine", "ejs");
 // app.use(express.bodyParser({ keepExtensions: true, uploadDir: __dirname + '/public' }));
app.use(methodOverride("_method"));
mongoose.set('useFindAndModify', false);
app.use(express.static(__dirname));


var blogSchema = mongoose.Schema({
	title: String,
	price:String,
	oldprice:String,
	name: String,
	image: String,
	body: String,
	size1: String,
	size2: String,
	size3: String,
	size4: String,
	size5: String,
	size6: String,
	size7: String,
	size8: String,
	
});

var Blog = mongoose.model("Blog", blogSchema);


app.get("/", function(req,res){
	res.redirect("/marlyn");
});


app.get("/marlyn", function(req,res){
	var p=0;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("index", {blogs: blogs, p:p});}
	});
});

app.get("/marlyn/login",function(req,res){
	res.render("admin");
});

app.post("/marlyn/login",function(req,res){
	if(req.body.pass === "aXj872hfr5"){ 
		res.redirect("/marlyn/aXj872hfr5");}
	else res.redirect("/marlyn");
});

app.get("/marlyn/aXj872hfr5", function(req,res){	
	var p=1;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("index", {blogs: blogs, p:p});}
	});
});

app.get("/marlyn/contacts", function(req,res){
	var p=0;
	res.render("contacts");
	
});

app.get("/marlyn/gerryweber",function(req,res){
	var p=0;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("small", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/aXj872hfr5/gerryweber",function(req,res){
	var p=1;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("small", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/taifun",function(req,res){
	var p=0;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("taifun", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/aXj872hfr5/taifun",function(req,res){
	var p=1;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("taifun", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/leconte",function(req,res){
	var p=0;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("leconte", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/aXj872hfr5/leconte",function(req,res){
	var p=1;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("leconte", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/monari",function(req,res){
	var p=0;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("monari", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/aXj872hfr5/monari",function(req,res){
	var p=1;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("monari", {blogs: blogs,p:p});}
	});
});


app.get("/marlyn/oui",function(req,res){
	var p=0;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("oui", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/aXj872hfr5/oui",function(req,res){
	var p=1;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("oui", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/imperial",function(req,res){
	var p=0;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("imperial", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/aXj872hfr5/imperial",function(req,res){
	var p=1;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("imperial", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/rosaschok",function(req,res){
	var p=0;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("rosaschok", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/aXj872hfr5/rosaschok",function(req,res){
	var p=1;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("rosaschok", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/vipart",function(req,res){
	var p=0;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("vipart", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/aXj872hfr5/vipart",function(req,res){
	var p=1;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("vipart", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/blackrich",function(req,res){
	var p=0;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("blackrich", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/aXj872hfr5/blackrich",function(req,res){
	var p=1;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("blackrich", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/kosmika",function(req,res){
	var p=0;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("kosmika", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/aXj872hfr5/kosmika",function(req,res){
	var p=1;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("kosmika", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/exxposeline",function(req,res){
	var p=0;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("exxposeline", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/aXj872hfr5/exxposeline",function(req,res){
	var p=1;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("exxposeline", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/vangelisa",function(req,res){
	var p=0;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("vangelisa", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/aXj872hfr5/vangelisa",function(req,res){
	var p=1;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("vangelisa", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/phardi",function(req,res){
	var p=0;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("phardi", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/aXj872hfr5/phardi",function(req,res){
	var p=1;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("phardi", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/size1",function(req,res){
	var p=0;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("sizes/size1.ejs", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/aXj872hfr5/size1",function(req,res){
	var p=1;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("sizes/size1.ejs", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/size2",function(req,res){
	var p=0;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("sizes/size2.ejs", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/aXj872hfr5/size2",function(req,res){
	var p=1;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("sizes/size2.ejs", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/size3",function(req,res){
	var p=0;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("sizes/size3.ejs", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/aXj872hfr5/size3",function(req,res){
	var p=1;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("sizes/size3.ejs", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/size4",function(req,res){
	var p=0;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("sizes/size4.ejs", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/aXj872hfr5/size4",function(req,res){
	var p=1;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("sizes/size4.ejs", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/size5",function(req,res){
	var p=0;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("sizes/size5.ejs", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/aXj872hfr5/size5",function(req,res){
	var p=1;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("sizes/size5.ejs", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/size6",function(req,res){
	var p=0;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("sizes/size6.ejs", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/aXj872hfr5/size6",function(req,res){
	var p=1;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("sizes/size6.ejs", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/size7",function(req,res){
	var p=0;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("sizes/size7.ejs", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/aXj872hfr5/size7",function(req,res){
	var p=1;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("sizes/size7.ejs", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/size8",function(req,res){
	var p=0;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("sizes/size8.ejs", {blogs: blogs,p:p});}
	});
});

app.get("/marlyn/aXj872hfr5/size8",function(req,res){
	var p=1;
	Blog.find({},function(err,blogs){
		if(err)console.log(err);
		else{res.render("sizes/size8.ejs", {blogs: blogs,p:p});}
	});
})





app.get("/marlyn/aXj872hfr5/new",function(req,res){
	res.render("new");

     
});



app.post("/marlyn/aXj872hfr5", upload.single('body[image]'), function(req,res){
	req.body.blog.image = "/uploads/"+req.file.filename;
	  Blog.create(req.body.blog,function(err,newBlog){
		if(err)res.render("new");
		else res.redirect("/marlyn/aXj872hfr5");
		
	});
});


app.get("/marlyn/:id",function(req,res){
	var p=0;
	Blog.findById(req.params.id, function(err,foundBlog){
		if(err)res.redirect("/blogs");
		else{ res.render("show", {blog:foundBlog, p:p});
			}
	});
});

app.get("/marlyn/aXj872hfr5/:id",function(req,res){
	var p=1;
	Blog.findById(req.params.id, function(err,foundBlog){
		if(err)res.redirect("/blogs");
		else{ res.render("show", {blog:foundBlog, p:p});
			}
	});
});


app.get("/marlyn/aXj872hfr5/:id/edit", function(req,res){
	Blog.findByIdAndUpdate(req.params.id, {size1:"off",size2:"off",size3:"off",size4:"off",size5:"off",size6:"off",size7:"off",size8:"off"}, function(err,foundBlog){
		if(err)console.log(err);
	});
	Blog.findById(req.params.id, function(err,foundBlog){ 
		if(err)console.log(err);
		else{
			res.render("edit", {blog : foundBlog});
		}
	});
});

app.put("/marlyn/aXj872hfr5/:id",function(req,res){
	Blog.findByIdAndUpdate(req.params.id, req.body.blog, function(err,foundBlog){
		if(err)console.log(err);
		else res.redirect("/marlyn/aXj872hfr5/" + req.params.id); 
	});
});


app.delete("/marlyn/aXj872hfr5/:id", function(req,res){
	Blog.findByIdAndDelete(req.params.id, function(err){
		if(err){res.redirect("/blogs");}
		else {
			res.redirect("/marlyn/aXj872hfr5");
		}
	});
});


app.listen(3000, function(){
	console.log("Alles geht`s gut");
})